// === cloud_preprocess.h ===
#pragma once

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <sensor_msgs/PointCloud2.h>

namespace faster_lio {

// 点云预处理参数
struct CloudPreprocessParams {
    bool enable_filter = true;       // 一键开关滤波器
    int sor_mean_k = 50;             // 统计滤波器邻域数量
    double sor_stddev_thresh = 1.0;  // 统计滤波器标准差阈值
    float voxel_leaf_size = 0.2f;    // 体素滤波器体素大小
    bool remove_ground = false;      // 是否去除地面点
};

// 全局参数实例
extern CloudPreprocessParams preprocess_params;

// 点云预处理接口（使用 PointXYZINormal 作为输出类型）
void CloudPreprocess(pcl::PointCloud<pcl::PointXYZINormal>::Ptr& cloud_in_out);

} // namespace faster_lio

