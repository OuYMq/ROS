#pragma once

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <Eigen/Dense>
#include <unordered_map>
#include <vector>

class LoopDetector {
public:
    LoopDetector();

    void AddKeyframe(int id, const pcl::PointCloud<pcl::PointXYZINormal>::Ptr& cloud);

    // 检测是否和已有关键帧形成回环
    // 返回 true 表示检测到回环，matched_id 是回环帧的 id，relative_pose 是两帧之间的相对位姿（由 ICP 获得）
    bool DetectLoop(const struct PoseGraphNode& current_node, int& matched_id, Eigen::Isometry3d& relative_pose);

private:
    std::unordered_map<int, pcl::PointCloud<pcl::PointXYZINormal>::Ptr> keyframes_;  // 保存所有关键帧点云

    // ICP 参数（可设为 YAML 可调）
    double fitness_threshold_ = 0.5;      // ICP 拟合误差阈值
    double max_translation_ = 5.0;        // 平移距离阈值（米）
    double max_rotation_deg_ = 20.0;      // 旋转角度阈值（角度）
};

